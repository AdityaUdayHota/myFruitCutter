var play = 1;
var end = 0;
var gameState = 1;

var sword,swordImage;
var fruitsGroup,fruit1,fruit2,fruit3,fruit4;
var aliensGroup,alien1,alien2;

var score;

var cuttingSound,gameOverSound;

function preload(){
  
 alien1 = loadImage("alien1.png");
 alien2 = loadImage("alien2.png");
  
swordImage = loadImage("sword.png");
  fruit1 = loadImage("fruit1.png");
  fruit2 = loadImage("fruit2.png");
  fruit3 = loadImage("fruit3.png");
  fruit4 = loadImage("fruit4.png");
 gameOverImage = loadImage("gameover.png");
  
  cuttingSound = loadSound("knifeSwooshSound.mp3");
  gameOverSound = loadSound("gameover.mp3")
}

function setup(){
 createCanvas(500,500) ;
  
  sword = createSprite(250,250,10,10);
  sword.addImage(swordImage);
  sword.scale=0.5;
  
  
  score = 0;
  
  fruitGroup = new Group();
  alienGroup = new Group();
}

function draw(){
background("skyblue");
text("Score:"+score,450,25);
  
  if(gameState===1){
  
  sword.x=World.mouseX;
  sword.y=World.mouseY;
  
  if(fruitGroup.isTouching(sword)){
    fruitGroup.destroyEach();
    score=score+1;
    cuttingSound.play();
    
  }
    alienAttack();
    fruitChop();
  }
  
 if(alienGroup.isTouching(sword)){
    gameState=0;
    alienGroup.destroyEach();
   sword.addImage(gameOverImage);
   gameOverSound.play();
   
  }
  
 if(gameState === 0) {
   
   fruitGroup.setLifetimeEach(0);
   alienGroup.setLifetimeEach(0);
   fruitGroup.setVelocityXEach(0);
   alienGroup.setVelocityXEach(0);
   sword.addImage(gameOverImage);
   sword.scale=2;
   sword.x=250;
   sword.y=250;
 }
  
  fruitChop();
  
  
  
  drawSprites();
  
}

function fruitChop(){
  
  if(World.frameCount%75===0){
    fruit = createSprite(350,10,10,10);
    fruit.scale=0.2;
    
    p = Math.round(random(1,2));
    if(p == 1){
      fruit.x=400;
      fruit.velocityX=-(5+score/100);
    }
    else if(p == 2){
      fruit.x=10;
      fruit.velocityX=(5+score/100);
    }
    r = Math.round(random(1,4));
    if(r == 1){
      fruit.addImage(fruit1);
    }
    else if(r == 2){
      fruit.addImage(fruit2)
    }
    else if(r == 3){
      fruit.addImage(fruit3)
    }
    else if(r == 4){
      fruit.addImage(fruit4);
    }
    fruit.y=Math.round(random(50,340));
    fruit.setLifetime=100;
    
    fruitGroup.add(fruit);
  }
}

function alienAttack(){
  
  if(World.frameCount%80===0){
    alien = createSprite(350,10,10,10);
    l=Math.round(random(1,2));
    if(l == 1){
      alien.addImage(alien1);
    }
    else if(l == 2){
      alien.addImage(alien2);
    }
    alien.y=Math.round(random(50,340));
    alien.velocityX=-(8+score/10);
    alien.setLifetime=100;
    
    alienGroup.add(alien)
  }
  
}